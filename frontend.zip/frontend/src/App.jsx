import { useState } from 'react'
import './App.css'
import Navbar from './components/Navbar'
import Home from './pages/home'
import { Outlet } from 'react-router'


function App() {
  const [count, setCount] = useState(0)

  return (
    <>
   <div className='bg-black w-full min-h-screen '>

     <Navbar/>
     {/* <Home/> */}
     <Outlet/>
   </div>
    </>
  )
}

export default App
