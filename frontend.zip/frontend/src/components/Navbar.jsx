import React from 'react'
import {SteeringWheelIcon} from "@phosphor-icons/react"
import { Link, useNavigate } from 'react-router';
import { useAuth } from '../hooks/useAuth';
// import { NavLink } from "react-router";
// import { Link } from 'react-router-dom';

const links = [
  { to: "/", label: "Home" },
  { to: "/meets", label: "Meets" },
  { to: "/garage", label: "My Garage" },
];

function Navbar() {
  const navigate = useNavigate();

  const {user, setUser} = useAuth()

  const handleLogout = () =>{
    localStorage.removeItem("token")
    setUser(null)
  }

  return (
    <header className='sticky top-0 bg-black/70 z-50'>
        <div className='px-2 flex justify-between w-full h-16 items-center '>
        <div className='flex flex-wrape h-full items-center'>
        <SteeringWheelIcon size={32} weight="fill" className='text-primary mr-2' color='#E21D48'/>
        <span className='text-lg font-bold text-white'>SUPER</span>
        <span className='text-lg font-bold text-[#E21D48]'>MEET</span>
        </div>  
        <nav className='flex gap-10'>
          {links.map((li) => (
            <Link
            className=' hover:[#E21D48] cursor-pointer font-light text-white'
            key={li.to}
            to={li.to}
            >{li.label}
            </Link>
          )
          )}
        </nav>
        <div className='flex '>
          { user ?

            (
            <div className='flex  gap-4 '>
             <p className='px-3 py-2 text-white uppercase text-xs'>{`${user.name} - ${user.role}`}</p>
            <button onClick={handleLogout} className='text-white px-3 py-1  mr-1 hover:bg-yellow-200 hover:text-black cursor-pointer uppercase border border-amber-50 text-sm '>Logout</button>
            </div>
            ):(
            
          <button onClick={() => navigate("/request-otp")} className=' px-6 py-1 mr-2 bg-[#E21D48] hover:bg-[#E21D48]/90 cursor-pointer'>Join</button>)
        }
        </div>
        </div>
    </header>
  )
}

export default Navbar