import { QueryClient, useQuery } from "@tanstack/react-query";
import client from "../api/client";



export function useMeet(){
    return useQuery({
      queryKey: [ "meets"],
      queryFn: async() => client.get( "/meets",
      {
    params: {
      page: 1,
      limit: 10,
    },
    withCredentials: true,
  })
    }
    )
}