import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import MeetCart from '../components/MeetCard';
import { ArrowRightIcon, ShieldCheckIcon, LockIcon, FlagIcon } from "@phosphor-icons/react";
import client from '../api/client';
import { useAuth } from '../hooks/useAuth';
import { useMeet } from '../hooks/useMeets';

const BANNERS = [
  {
    img: "https://images.unsplash.com/photo-1610374634235-b51ef357f905?crop=entropy&cs=srgb&fm=jpg&q=85&w=2000",
    kicker: "This season",
    title: "Where supercars gather after dark",
    sub: "Find the meet. Verify your ride. Roll in.",
  },
  {
    img: "https://images.pexels.com/photos/35416467/pexels-photo-35416467.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=2000",
    kicker: "Private access",
    title: "Invite-only garage nights",
    sub: "Limited passes. Serious machinery.",
  },
  {
    img: "https://images.unsplash.com/photo-1581439645268-ea7bbe6bd091?crop=entropy&cs=srgb&fm=jpg&q=85&w=2000",
    kicker: "Every weekend",
    title: "Canyon runs & sunrise cruises",
    sub: "Hosted by verified enthusiasts.",
  },
];

const INFO = [
  { icon: FlagIcon, t: "Hosted meets", d: "Hosts and admins publish date, time and exact location." },
  { icon: ShieldCheckIcon, t: "RC verified rides", d: "Registration checked against the government registry." },
  { icon: LockIcon, t: "Private passes", d: "Paid, capped guest lists for exclusive garage nights." },

]

function Home() {

  

  const{data, isLoading} = useMeet()
  console.log(" meet data", data)
  console.log("whats going on")
  // const fetchCard = async () => {
  //  const response = await client.get(
  //     "/meets",
  //     {
  //   params: {
  //     page: 1,
  //     limit: 10,
  //   },
  //   withCredentials: true,
  // }
  // )
  // console.log("fetchCard", response);
  // }

  const [slide, setSlide] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setSlide((s) => (s + 1) % BANNERS.length), 6000)
    return () => clearInterval(t);
  }, [])

  const b = BANNERS[slide];
  return (
    <div className='relative bg-black'>
      <section className="z-0 relative h-[78vh] min-h-120 overflow-hidden grain">
        {BANNERS.map((banner, i) => (
          <img
            key={i}
            src={banner.img}
            alt=""
            className="absolute inset-0 w-full h-full object-cover transition-opacity duration-1000"
            style={{ opacity: i === slide ? 1 : 0 }}
          />
        ))}
        <div className="absolute inset-0 bg-linear-to-r from-black via-black/70 to-black/20">
          <div className="max-w-7xl w-full mx-auto absolute bottom-0 z-40 flex flex-col  text-white pb-20 px-5 ">
            <motion.div key={slide} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="max-w-3xl">
              <p className="text-sm tracking-[0.35em] font-light text-accent text-yellow-500 uppercase mb-2">{b.kicker}</p>
              <h1 className="text-4xl uppercase md:text-6xl font-extrabold mb-4">{b.title}</h1>
              <p className="text-sm md:text-sm">{b.sub}</p>
              <button className="mt-6 px-6 py-3 bg-red-600 hover:bg-red-700  text-white transition-colors font-light duration-300">Browse Meets</button>
              <button className="mt-6 ml-4 px-6 py-3 bg-gray-800 hover:bg-gray-900 text-white font-light transition-colors duration-300">Verify My Car</button>
            </motion.div>

          </div>
        </div>
      </section>

         // Info Section
      <section className='bg-[#141414] mb-8'>
        <div className="flex flex-col md:flex-row justify-around items-center max-w-7xl mx-auto py-20 px-5 gap-10">
          { INFO.map(({icon:Icon, t, d}) => (
            <div className="flex gap-4" key={t}>
              <Icon size={32}  className='text-primary mr-2' color='#E21D48'/>
              <div>
              <h3 className="text-xl textbase uppercase text-white font-bold mb-2">{t}</h3>
              <p className=" text-white">{d}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

        // Meet Cards Section
      <section className='w-full px-4 pb-8'>
        <div className='mb-8'>
          <p className='text-sm tracking-[0.35em] text-red-700 uppercase text-primary mb-3'>On the calendar</p>
          <h2 className='md:text-4xl uppercase text-white font-black text-3xl'>Upcoming meets</h2>
        </div>

        <div className='grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3'>

          <MeetCart />
          <MeetCart />
          <MeetCart />
          <MeetCart />
          <MeetCart />
          <MeetCart />
        </div>
      </section>
    </div>
  )
}

export default Home