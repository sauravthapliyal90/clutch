import React from 'react'

function MyGarage() {
  return (
    <div>MyGarage</div>
  )
}

export default MyGarage