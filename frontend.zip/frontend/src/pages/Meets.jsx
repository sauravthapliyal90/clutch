import React from 'react'

function Meets() {
  return (
    <div className='h-full'>Meet</div>
  )
}

export default Meets